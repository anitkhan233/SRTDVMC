package org.cloudbus.cloudsim;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHostUtilizationHistory;
/*
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G4Xeon3040;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G5Xeon3075;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerFujitsuPrimergyRX4770M4XeonPlatinum8176M;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerFujitsuPrimergyRX2540M4XeonPlatinum8176M;
*/
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerDellPowerEdgeR940XeonPlatinum8180;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHPProLiantDL560Gen10XeonPlatinum8180;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHPProLiantML350Gen10XeonPlatinum8180;



public class HostsSortByAscendingOrderOfPowerConsumptionModel {
	/**
 	 * Sort hosts in ascending order based on hosts' enery consumption rate or power efficiency.
 	 * 
 	 * @param hostList the host list
 	 */
	
//----------Old One Created by Anton-----------------------------------------------------------------------------//	
/*	
 	public static <T extends PowerHost> void sortHostsByAscendingOrderOfPowerConsumptionModel(List<T> hostList) 
 	{
 		Collections.sort(hostList, new Comparator<T>() {@Override
 			public int compare(T a, T b) throws ClassCastException 
			{
				//double currentTime = CloudSim.clock();
				Double aPowerConsumptionAtIdle = null;
				Double bPowerConsumptionAtIdle = null;
				if( a.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G4Xeon3040)
				{
					aPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G4Xeon3040.power[0];
				}
				else if(a.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G5Xeon3075)
				{
					aPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G5Xeon3075.power[0];
				}
				
				if( b.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G4Xeon3040)
				{
					bPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G4Xeon3040.power[0];
				}
				else if(b.getPowerModel() instanceof PowerModelSpecPowerHpProLiantMl110G5Xeon3075)
				{
					bPowerConsumptionAtIdle = PowerModelSpecPowerHpProLiantMl110G5Xeon3075.power[0];
				}
				//Double aPowerConsumption = ;
				return aPowerConsumptionAtIdle.compareTo(bPowerConsumptionAtIdle);
			}
 		});
 	}
 	
 */	
//-----------------End of Old one created by Anton-------------------------------------------------------//

//--------------Start of New One created by me---------------------------------------------
/*	
 	public static <T extends PowerHost> void sortHostsByAscendingOrderOfPowerConsumptionModel(List<T> hostList) 
 	{
 		Collections.sort(hostList, new Comparator<T>() {@Override
 			public int compare(T a, T b) throws ClassCastException 
			{
				//double currentTime = CloudSim.clock();
				Double aPowerConsumptionAtIdle = null;
				Double bPowerConsumptionAtIdle = null;
				if( a.getPowerModel() instanceof PowerModelSpecPowerFujitsuPrimergyRX4770M4XeonPlatinum8176M)
				{
					aPowerConsumptionAtIdle = PowerModelSpecPowerFujitsuPrimergyRX4770M4XeonPlatinum8176M.power[0];
				}
				else if(a.getPowerModel() instanceof PowerModelSpecPowerFujitsuPrimergyRX2540M4XeonPlatinum8176M)
				{
					aPowerConsumptionAtIdle = PowerModelSpecPowerFujitsuPrimergyRX2540M4XeonPlatinum8176M.power[0];
				}
				
				if( b.getPowerModel() instanceof PowerModelSpecPowerFujitsuPrimergyRX4770M4XeonPlatinum8176M)
				{
					bPowerConsumptionAtIdle = PowerModelSpecPowerFujitsuPrimergyRX4770M4XeonPlatinum8176M.power[0];
				}
				else if(b.getPowerModel() instanceof PowerModelSpecPowerFujitsuPrimergyRX2540M4XeonPlatinum8176M)
				{
					bPowerConsumptionAtIdle = PowerModelSpecPowerFujitsuPrimergyRX2540M4XeonPlatinum8176M.power[0];
				}
				//Double aPowerConsumption = ;
				return aPowerConsumptionAtIdle.compareTo(bPowerConsumptionAtIdle);
			}
 		});
 	}

 */	
//0000000------ End of New One created by me----------------------------------------------------	


 	//--------------Start of New One created by me---------------------------------------------
 		
 	 	public static <T extends PowerHost> void sortHostsByAscendingOrderOfPowerConsumptionModel(List<T> hostList) 
 	 	{
 	 		Collections.sort(hostList, new Comparator<T>() {@Override
 	 			public int compare(T a, T b) throws ClassCastException 
 				{
 					//double currentTime = CloudSim.clock();
 					Double aPowerConsumptionAtIdle = null;
 					Double bPowerConsumptionAtIdle = null;
 					if( a.getPowerModel() instanceof PowerModelSpecPowerDellPowerEdgeR940XeonPlatinum8180)
 					{
 						aPowerConsumptionAtIdle = PowerModelSpecPowerDellPowerEdgeR940XeonPlatinum8180.power[0];
 					}
 					else if(a.getPowerModel() instanceof PowerModelSpecPowerHPProLiantML350Gen10XeonPlatinum8180)
 					{
 						aPowerConsumptionAtIdle = PowerModelSpecPowerHPProLiantML350Gen10XeonPlatinum8180.power[0];
 					}
 					else if(a.getPowerModel() instanceof PowerModelSpecPowerHPProLiantDL560Gen10XeonPlatinum8180)
 					{
 						aPowerConsumptionAtIdle = PowerModelSpecPowerHPProLiantDL560Gen10XeonPlatinum8180.power[0];
 	 					
 					}
 					
 					if( b.getPowerModel() instanceof PowerModelSpecPowerDellPowerEdgeR940XeonPlatinum8180)
 					{
 						bPowerConsumptionAtIdle = PowerModelSpecPowerDellPowerEdgeR940XeonPlatinum8180.power[0];
 					}
 					else if(b.getPowerModel() instanceof PowerModelSpecPowerHPProLiantML350Gen10XeonPlatinum8180)
 					{
 						bPowerConsumptionAtIdle = PowerModelSpecPowerHPProLiantML350Gen10XeonPlatinum8180.power[0];
 					}
 					else if(b.getPowerModel() instanceof PowerModelSpecPowerHPProLiantDL560Gen10XeonPlatinum8180)
 					{
 						bPowerConsumptionAtIdle = PowerModelSpecPowerHPProLiantDL560Gen10XeonPlatinum8180.power[0];
 	 					
 					}
 					
 					//Double aPowerConsumption = ;
 					return aPowerConsumptionAtIdle.compareTo(bPowerConsumptionAtIdle);
 				}
 	 		});
 	 	}

 	 	
 	//0000000------ End of New One created by me----------------------------------------------------	

 	
 	
 	
}
