package org.cloudbus.cloudsim;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.cloudbus.cloudsim.core.CloudSim;

public class HostsSortByDescendingOrderOfReleaseTime {
	/**
 	 * Sort hosts in descending order based on hosts' release time.
 	 * 
 	 * @param hostList the host list
 	 */
 	public static <T extends Host> void sortHostsByDescendingOrderOfReleaseTime(List<T> hostList) 
 	{
 		Collections.sort(hostList, new Comparator<T>() {@Override
 			public int compare(T a, T b) throws ClassCastException 
 			{
 				double currentTime = CloudSim.clock();
 				Double aReleaseTime = a.getHostReleaseTime(currentTime);
 				Double bReleaseTime = b.getHostReleaseTime(currentTime);
 				return bReleaseTime.compareTo(aReleaseTime);
 			}
 		});
 	}


}
