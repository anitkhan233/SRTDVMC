package org.cloudbus.cloudsim.examples.power;

import java.util.Random;

import org.cloudbus.cloudsim.power.models.PowerModel;
//import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G4Xeon3040;
//import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G5Xeon3075;
//import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerFujitsuPrimergyRX2540M4XeonPlatinum8176M;
//import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerFujitsuPrimergyRX4770M4XeonPlatinum8176M;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerDellPowerEdgeR940XeonPlatinum8180;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHPProLiantDL560Gen10XeonPlatinum8180;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHPProLiantML350Gen10XeonPlatinum8180;
/**
 * If you are using any algorithms, policies or workload included in the power package, please cite
 * the following paper:
 *
 * Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012
 *
 * @author Anton Beloglazov
 * @since Jan 6, 2012
 */
public class Constants {

	public final static boolean ENABLE_OUTPUT = true;
	public final static boolean OUTPUT_CSV    = false;

	public final static double SCHEDULING_INTERVAL = 300;
	/*//old one
	public final static double SIMULATION_LIMIT = 24 * 60 * 60;
	*/
	//next old
	//public final static double SIMULATION_LIMIT = 2 * 60 * 60;

	// new one
	//public final static double SIMULATION_LIMIT = 24 * 60 * 60;
	public final static double SIMULATION_LIMIT = 24 * 60 * 60;

	/*
//----------start of Anton's Cloudlet Length---------------------------------------
	public final static int CLOUDLET_LENGTH	= 2500 * (int) SIMULATION_LIMIT;
//-------------end of anton's cloudlet Length-------------------------------------------	
 * 
 */
	
	/*
	//-----start of my added------------------------------------------------
	//Constants.maximumIndex maximum how many different cloudlet lengths are there
	//Constants.maximumIndex is used in RandomHelper to generate random in maximum range of Constants.maximumIndex
	public static int maximumCloudletListIndex = 99; //update it with the total number of different cloudlet lengths
	//Just update Constants.maximumIndex with the change in total number of different cloudlets
	//if we change Constants.maximumInde, then in RandomHelper we wouldn't need to change
	
	static int length1 = (1 * (int) SIMULATION_LIMIT);
	static int length2 = (2 * (int) SIMULATION_LIMIT);
	static int length3 = (3 * (int) SIMULATION_LIMIT);
	static int length4 = (4 * (int) SIMULATION_LIMIT);
	static int length5 = (5 * (int) SIMULATION_LIMIT);
	static int length6 = (6 * (int) SIMULATION_LIMIT);
	static int length7 = (7 * (int) SIMULATION_LIMIT);
	static int length8 = (8 * (int) SIMULATION_LIMIT);
	static int length9 = (9 * (int) SIMULATION_LIMIT);
	static int length10 = (10 * (int) SIMULATION_LIMIT);
	static int length11 = (15 * (int) SIMULATION_LIMIT);
	static int length12 = (20 * (int) SIMULATION_LIMIT);
	static int length13 = (30 * (int) SIMULATION_LIMIT);
	static int length14 = (40 * (int) SIMULATION_LIMIT);
	static int length15 = (50 * (int) SIMULATION_LIMIT);
	static int length16 = (60 * (int) SIMULATION_LIMIT);
	static int length17 = (70 * (int) SIMULATION_LIMIT);
	static int length18 = (80 * (int) SIMULATION_LIMIT);
	static int length19 = (90 * (int) SIMULATION_LIMIT);
	static int length20 = (100 * (int) SIMULATION_LIMIT);
	static int length21 = (250 * (int) SIMULATION_LIMIT);
	static int length22 = (200 * (int) SIMULATION_LIMIT);
	static int length23 = (300 * (int) SIMULATION_LIMIT);
	static int length24 = (400 * (int) SIMULATION_LIMIT);
	static int length25 = (500 * (int) SIMULATION_LIMIT);
	static int length26 = (600 * (int) SIMULATION_LIMIT);
	static int length27 = (700 * (int) SIMULATION_LIMIT);
	static int length28 = (800 * (int) SIMULATION_LIMIT);
	static int length29 = (900 * (int) SIMULATION_LIMIT);
	static int length30 = (1000 * (int) SIMULATION_LIMIT);
	static int length31 = (1100 * (int) SIMULATION_LIMIT);
	static int length32 = (1200 * (int) SIMULATION_LIMIT);
	static int length33 = (1300 * (int) SIMULATION_LIMIT);
	static int length34 = (1400 * (int) SIMULATION_LIMIT);
	static int length35 = (1500 * (int) SIMULATION_LIMIT);
	static int length36 = (1600 * (int) SIMULATION_LIMIT);
	static int length37 = (1700 * (int) SIMULATION_LIMIT);
	static int length38 = (1800 * (int) SIMULATION_LIMIT);
	static int length39 = (1900 * (int) SIMULATION_LIMIT);
	static int length40 = (2000 * (int) SIMULATION_LIMIT);
	static int length41 = (2050 * (int) SIMULATION_LIMIT);
	static int length42 = (2100 * (int) SIMULATION_LIMIT);
	static int length43 = (2150 * (int) SIMULATION_LIMIT);
	static int length44 = (2200 * (int) SIMULATION_LIMIT);
	static int length45 = (2250 * (int) SIMULATION_LIMIT);
	static int length46 = (2300 * (int) SIMULATION_LIMIT);
	static int length47 = (2350 * (int) SIMULATION_LIMIT);
	static int length48 = (2400 * (int) SIMULATION_LIMIT);
	static int length49 = (2450 * (int) SIMULATION_LIMIT);
	static int length50 = (2500 * (int) SIMULATION_LIMIT);
	static int length51 = (2550 * (int) SIMULATION_LIMIT);
	static int length52 = (2600 * (int) SIMULATION_LIMIT);
	static int length53 = (2650 * (int) SIMULATION_LIMIT);
	static int length54 = (2700 * (int) SIMULATION_LIMIT);
	static int length55 = (2750 * (int) SIMULATION_LIMIT);
	static int length56 = (2800 * (int) SIMULATION_LIMIT);
	static int length57 = (2850 * (int) SIMULATION_LIMIT);
	static int length58 = (2900 * (int) SIMULATION_LIMIT);
	static int length59 = (2950 * (int) SIMULATION_LIMIT);
	static int length60 = (3000 * (int) SIMULATION_LIMIT);
	static int length61 = (3050 * (int) SIMULATION_LIMIT);
	static int length62 = (3100 * (int) SIMULATION_LIMIT);
	static int length63 = (3250 * (int) SIMULATION_LIMIT);
	static int length64 = (3300 * (int) SIMULATION_LIMIT);
	static int length65 = (3350 * (int) SIMULATION_LIMIT);
	static int length66 = (3400 * (int) SIMULATION_LIMIT);
	static int length67 = (3450 * (int) SIMULATION_LIMIT);
	static int length68 = (3500 * (int) SIMULATION_LIMIT);
	static int length69 = (3550 * (int) SIMULATION_LIMIT);
	static int length70 = (3600 * (int) SIMULATION_LIMIT);
	static int length71 = (3650 * (int) SIMULATION_LIMIT);
	static int length72 = (3700 * (int) SIMULATION_LIMIT);
	static int length73 = (3750 * (int) SIMULATION_LIMIT);
	static int length74 = (3800 * (int) SIMULATION_LIMIT);
	static int length75 = (3850 * (int) SIMULATION_LIMIT);
	static int length76 = (3900 * (int) SIMULATION_LIMIT);
	static int length77 = (3950 * (int) SIMULATION_LIMIT);
	static int length78 = (4000 * (int) SIMULATION_LIMIT);
	static int length79 = (4250 * (int) SIMULATION_LIMIT);
	static int length80 = (4300 * (int) SIMULATION_LIMIT);
	static int length81 = (4350 * (int) SIMULATION_LIMIT);
	static int length82 = (4400 * (int) SIMULATION_LIMIT);
	static int length83 = (4450 * (int) SIMULATION_LIMIT);
	static int length84 = (4500 * (int) SIMULATION_LIMIT);
	static int length85 = (4550 * (int) SIMULATION_LIMIT);
	static int length86 = (4600 * (int) SIMULATION_LIMIT);
	static int length87 = (4650 * (int) SIMULATION_LIMIT);
	static int length88 = (4700 * (int) SIMULATION_LIMIT);
	static int length89 = (4750 * (int) SIMULATION_LIMIT);
	static int length90 = (4800 * (int) SIMULATION_LIMIT);
	static int length91 = (4850 * (int) SIMULATION_LIMIT);
	static int length92 = (4900 * (int) SIMULATION_LIMIT);
	static int length93 = (4950 * (int) SIMULATION_LIMIT);
	static int length94 = (5000 * (int) SIMULATION_LIMIT);
	static int length95 = (5050 * (int) SIMULATION_LIMIT);
	static int length96 = (5100 * (int) SIMULATION_LIMIT);
	static int length97 = (5150 * (int) SIMULATION_LIMIT);
	static int length98 = (5200 * (int) SIMULATION_LIMIT);
	static int length99 = (5250 * (int) SIMULATION_LIMIT);
	static int length100 = (5300 * (int) SIMULATION_LIMIT);
	
	
	public final static int[] CLOUDLET_LENGTH	= { 
			length1, length2, length3, length4, length5, 
			length6, length7, length8, length9, length10,
			length11, length12, length13, length14, length15, 
			length16, length17, length18, length19, length20, 
			length21, length22, length23, length24, length25, 
			length26, length27, length28, length29, length30,
			length31, length32, length33, length34, length35, 
			length36, length37, length38, length39, length40, 
			length41, length42, length43, length44, length45, 
			length46, length47, length48, length49, length50, 
			length51, length52, length53, length54, length55, 
			length56, length57, length58, length59, length60,
			length61, length62, length63, length64, length65, 
			length66, length67, length68, length69, length70, 
			length71, length72, length73, length74, length75, 
			length76, length77, length78, length79, length80,
			length81, length82, length83, length84, length85, 
			length86, length87, length88, length89, length90, 
			length91, length92, length93, length94, length95, 
			length96, length97, length98, length99, length100};
	
	//-----end of my added----------------------------------------------
	*/
	
	
	//----start of uncertain client information------------------------------//
	//I have added following getStochastic() variable to deal with inaccurate VMRT given by users
	static Random randomObject = new Random();
	
	public static double stochastic;
	
	//getStochastic() generates a number between 1.05 and 0.95
	//the value returned by getStochastic() will be multiplied with user provided VMRT
	public static double getStochastic()	
	{
		//value of stochastic is between -1 to 1, as nextDouble() returns between 0.0 and 1.0 
		stochastic = 1.0 - (2.0 * randomObject.nextDouble()); //value of stochastic is between -1 to 1
		return (1 + (0.05 * stochastic)); //returns value between 1.05 and .95
	}
	

	
	//-----start of my added------------------------------------------------
	//Constants.maximumIndex maximum how many different cloudlet lengths are there
	//Constants.maximumIndex is used in RandomHelper to generate random in maximum range of Constants.maximumIndex
	public static int maximumCloudletListIndex = 99; //update it with the total number of different cloudlet lengths
	//Just update Constants.maximumIndex with the change in total number of different cloudlets
	//if we change Constants.maximumInde, then in RandomHelper we wouldn't need to change
	//I have later added * getStochastic() on 6 Feb, 2018
	//also I have made length1 as double on 6 Feb, 2018 which was earlier int
	static double length1 = (1 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length2 = (2 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length3 = (3 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length4 = (4 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length5 = (5 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length6 = (6 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length7 = (7 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length8 = (8 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length9 = (9 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length10 = (10 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length11 = (15 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length12 = (20 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length13 = (30 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length14 = (40 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length15 = (50 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length16 = (60 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length17 = (70 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length18 = (80 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length19 = (90 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length20 = (100 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length21 = (250 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length22 = (200 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length23 = (300 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length24 = (400 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length25 = (500 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length26 = (600 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length27 = (700 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length28 = (800 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length29 = (900 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length30 = (1000 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length31 = (1100 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length32 = (1200 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length33 = (1300 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length34 = (1400 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length35 = (1500 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length36 = (1600 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length37 = (1700 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length38 = (1800 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length39 = (1900 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length40 = (2000 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length41 = (2050 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length42 = (2100 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length43 = (2150 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length44 = (2200 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length45 = (2250 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length46 = (2300 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length47 = (2350 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length48 = (2400 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length49 = (2450 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length50 = (2500 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length51 = (2550 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length52 = (2600 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length53 = (2650 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length54 = (2700 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length55 = (2750 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length56 = (2800 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length57 = (2850 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length58 = (2900 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length59 = (2950 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length60 = (3000 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length61 = (3050 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length62 = (3100 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length63 = (3250 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length64 = (3300 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length65 = (3350 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length66 = (3400 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length67 = (3450 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length68 = (3500 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length69 = (3550 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length70 = (3600 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length71 = (3650 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length72 = (3700 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length73 = (3750 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length74 = (3800 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length75 = (3850 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length76 = (3900 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length77 = (3950 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length78 = (4000 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length79 = (4250 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length80 = (4300 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length81 = (4350 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length82 = (4400 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length83 = (4450 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length84 = (4500 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length85 = (4550 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length86 = (4600 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length87 = (4650 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length88 = (4700 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length89 = (4750 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length90 = (4800 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length91 = (4850 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length92 = (4900 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length93 = (4950 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length94 = (5000 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length95 = (5050 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length96 = (5100 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length97 = (5150 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length98 = (5200 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length99 = (5250 * (long) SIMULATION_LIMIT) * getStochastic();
	static double length100 = (5300 * (long) SIMULATION_LIMIT) * getStochastic();
	
	//I have later modified length1 as long, earlier it was int
	public final static long[] CLOUDLET_LENGTH	= { 
			(long) length1, (long) length2, (long) length3, (long) length4, (long) length5, 
			(long) length6, (long) length7, (long) length8, (long) length9, (long) length10,
			(long) length11, (long) length12, (long) length13, (long) length14, (long) length15, 
			(long) length16, (long) length17, (long) length18, (long) length19, (long) length20, 
			(long) length21, (long) length22, (long) length23, (long) length24, (long) length25, 
			(long) length26, (long) length27, (long) length28, (long) length29, (long) length30,
			(long) length31, (long) length32, (long) length33, (long) length34, (long) length35, 
			(long) length36, (long) length37, (long) length38, (long) length39, (long) length40, 
			(long) length41, (long) length42, (long) length43, (long) length44, (long) length45, 
			(long) length46, (long) length47, (long) length48, (long) length49, (long) length50, 
			(long) length51, (long) length52, (long) length53, (long) length54, (long) length55, 
			(long) length56, (long) length57, (long) length58, (long) length59, (long) length60,
			(long) length61, (long) length62, (long) length63, (long) length64, (long) length65, 
			(long) length66, (long) length67, (long) length68, (long) length69, (long) length70, 
			(long) length71, (long) length72, (long) length73, (long) length74, (long) length75, 
			(long) length76, (long) length77, (long) length78, (long) length79, (long) length80,
			(long) length81, (long) length82, (long) length83, (long) length84, (long) length85, 
			(long) length86, (long) length87, (long) length88, (long) length89, (long) length90, 
			(long) length91, (long) length92, (long) length93, (long) length94, (long) length95, 
			(long) length96, (long) length97, (long) length98, (long) length99, (long) length100};
	
	//-----end of my added----------------------------------------------	
	//-----end of my added----------------------------------------------

	
	
	
	//------end of uncertain client information
	
	
	public final static int CLOUDLET_PES	= 1;

	/*
	 * VM instance types:
	 *   High-Memory Extra Large Instance: 3.25 EC2 Compute Units, 8.55 GB // too much MIPS
	 *   High-CPU Medium Instance: 2.5 EC2 Compute Units, 0.85 GB
	 *   Extra Large Instance: 2 EC2 Compute Units, 3.75 GB
	 *   Small Instance: 1 EC2 Compute Unit, 1.7 GB
	 *   Micro Instance: 0.5 EC2 Compute Unit, 0.633 GB
	 *   We decrease the memory size two times to enable oversubscription
	 *
	 */
	public final static int VM_TYPES	= 4;
	public final static int[] VM_MIPS	= { 2500, 2000, 1000, 500 };
	public final static int[] VM_PES	= { 1, 1, 1, 1 };
	public final static int[] VM_RAM	= { 870,  1740, 1740, 613 };
	public final static int VM_BW		= 100000000; // 100 Mbit/s //I changed here
	public final static int VM_SIZE		= 2500; // 2.5 GB

//------Start of Anton's Old Hosts-------------------------------------------//
	/*
	 * Host types:
	 *   HP ProLiant ML110 G4 (1 x [Xeon 3040 1860 MHz, 2 cores], 4GB)
	 *   HP ProLiant ML110 G5 (1 x [Xeon 3075 2660 MHz, 2 cores], 4GB)
	 *   We increase the memory size to enable over-subscription (x4)
	 */
	/*
	public final static int HOST_TYPES	 = 2;
	public final static int[] HOST_MIPS	 = { 1860, 2660 };
	public final static int[] HOST_PES	 = { 2, 2 };
	public final static int[] HOST_RAM	 = { 4096, 4096 };
	public final static int HOST_BW		 = 1000000; // 1 Gbit/s
	public final static int HOST_STORAGE = 1000000; // 1 GB
	*/
//-----End of Anton's Old Hosts----------------------------------------------//
	
//------Start of New Servers-----------------------------------------------//	
	/*
	 * Host types:
	 *   FUJITSU PRIMERGY RX4770 M4 (4 x [Intel Xeon Platinum 8176M 2100 MHz or 2100 MIPS, 28 cores], 192GB)
	 *   It Has 4 chips or 4 cpu slots with one CPU(Processing Element) having 28 cores
	 *   So, Total # PES = 112 for RX4770 M4
	 *   As CPU Clock frequency 2100MHz, so can complete (2100*10^6) clock cycles/sec
	 *   If a single clock signal can execute an instruction
	 *   Then, in a second 2100,000,000 number of instructions can be executed
	 *   Simply Put, 2100 Million Instructions Per Second (2100 MIPS)
	 *   
	 *   FUJITSU PRIMERGY RX2540 M4 (2 x [Intel Xeon Platinum 8176M 2100 MHz or 2100 MIPS, 28 cores], 192GB)
	 *   It Has 2 chips or 2 cpu slots with one CPU(Processing Element) having 28 cores
	 *   So, Total # PES = 112 for RX4770 M4
	 *   As CPU Clock frequency 2100MHz, so can complete (2100*10^6) clock cycles/sec
	 *   If a single clock signal can execute an instruction
	 *   Then, in a second 2100,000,000 number of instructions can be executed
	 *   Simply Put, 2100 Million Instructions Per Second (2100 MIPS)
	 * 
	 */
/*	
	public final static int HOST_TYPES	 = 2;
	public final static int[] HOST_MIPS	 = { 2100, 2100 };
	public final static int[] HOST_PES	 = { 112, 56 };
	public final static int[] HOST_RAM	 = { 196608, 196608 };  //byte
	public final static int HOST_BW		 = 1000000000; // 1000Mbis/s or 1 Gbit/s
	public final static int HOST_STORAGE = 1000000; // 1 GB
*/
//-----End of New Servers--------------------------------------------------//	

	//------Start of New Servers-----------------------------------------------//	
		/*
		 * Host types:
		 *   Dell PowerEdge R940 (4 x [Intel Xeon Platinum 8180 2500 MHz or 2100 MIPS, 28 cores], 384GB)
		 *   It Has 4 chips or 4 cpu slots with one CPU(Processing Element) having 28 cores
		 *   So, Total # PES = 112 for R940
		 *   As CPU Clock frequency 2500MHz, so can complete (2500*10^6) clock cycles/sec
		 *   If a single clock signal can execute an instruction
		 *   Then, in a second 2500,000,000 number of instructions can be executed
		 *   Simply Put, 2500 Million Instructions Per Second (2500 MIPS)
		 *   
		 *   HP ProLiant ML350 Gen10 (2 x [Intel Xeon Platinum 8180M 2500 MHz or 2500 MIPS, 28 cores], 192GB)
		 *   It Has 2 chips or 2 cpu slots with one CPU(Processing Element) having 28 cores
		 *   So, Total # PES = 56 for ML350 Gen10
		 *   As CPU Clock frequency 2500MHz, so can complete (2500*10^6) clock cycles/sec
		 *   If a single clock signal can execute an instruction
		 *   Then, in a second 2500,000,000 number of instructions can be executed
		 *   Simply Put, 2500 Million Instructions Per Second (2500 MIPS)
		 *   
		 *   HP ProLiant DL560 Gen10 (4 x [Intel Xeon Platinum 8180M 2500 MHz or 2500 MIPS, 28 cores], 192GB)
		 *   It Has 4 chips or 4 cpu slots with one CPU(Processing Element) having 28 cores
		 *   So, Total # PES = 112 for DL560 Gen10
		 *   As CPU Clock frequency 2500MHz, so can complete (2500*10^6) clock cycles/sec
		 *   If a single clock signal can execute an instruction
		 *   Then, in a second 2500,000,000 number of instructions can be executed
		 *   Simply Put, 2500 Million Instructions Per Second (2500 MIPS)
		 * 
		 */
		
		public final static int HOST_TYPES	 = 3;
		public final static int[] HOST_MIPS	 = { 2500, 2500, 2500 };
		public final static int[] HOST_PES	 = { 112, 56, 112 };
		public final static int[] HOST_RAM	 = { 356352, 196608, 196608 };  //MB
		public final static int HOST_BW		 = 1000000000; // 1000Mbis/s or 1 Gbit/s
		public final static int HOST_STORAGE = 1000000; // 1 GB
	
	//-----End of New Servers--------------------------------------------------//
	
	//--I have replaced the old power model with the power model of new servers////
	public final static PowerModel[] HOST_POWER = {
			/*
		new PowerModelSpecPowerHpProLiantMl110G4Xeon3040(),
		new PowerModelSpecPowerHpProLiantMl110G5Xeon3075()
		*/
			/*
		new PowerModelSpecPowerFujitsuPrimergyRX4770M4XeonPlatinum8176M(),
		new PowerModelSpecPowerFujitsuPrimergyRX2540M4XeonPlatinum8176M()
		*/
		new	PowerModelSpecPowerDellPowerEdgeR940XeonPlatinum8180(),
		new PowerModelSpecPowerHPProLiantML350Gen10XeonPlatinum8180(),
		new PowerModelSpecPowerHPProLiantDL560Gen10XeonPlatinum8180()
	};

}
