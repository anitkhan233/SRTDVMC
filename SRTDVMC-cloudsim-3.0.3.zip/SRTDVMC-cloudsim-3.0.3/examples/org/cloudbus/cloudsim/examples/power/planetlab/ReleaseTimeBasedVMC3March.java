package org.cloudbus.cloudsim.examples.power.planetlab;

public class ReleaseTimeBasedVMC3March {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean enableOutput = true;
		boolean outputToFile = false;
		/* Old one
		String inputFolder = NonPowerAware.class.getClassLoader().getResource("workload/planetlab").getPath();
		*/
		//C:\Users\anit\eclipse-workspace\090318 Real Release Time New Servers cloudsim-3.0.3\examples\workload\planetlab//I modified
		String inputFolder = "C://Users//anit//eclipse-workspace//090318 Real Release Time New Servers cloudsim-3.0.3//examples//workload//planetlab";
		String outputFolder = "output";
		String workload = "20110303"; // PlanetLab workload
		String vmAllocationPolicy = "thr"; // Static Threshold (THR) VM allocation policy
		String vmSelectionPolicy = "mmt"; // Minimum Migration Time (MMT) VM selection policy
		String parameter = "0.8"; // the static utilization threshold
		//I added String realReleaseTimeCSVFileName to get real release time
		String directoryOfRealReleaseTimeCSVFile = new String("C://Users//anit//eclipse-workspace//datafiles__nectar");
		String realReleaseTimeCSVFileName = new String("2014-JAN.csv");
		String realReleaseTimeCSVFilePath = new String(directoryOfRealReleaseTimeCSVFile+"//"+realReleaseTimeCSVFileName);
				
		new PlanetLabRunner(
				enableOutput,
				outputToFile,
				inputFolder,
				outputFolder,
				workload,
				vmAllocationPolicy,
				vmSelectionPolicy,
				parameter,
				realReleaseTimeCSVFilePath); //I added realReleaseTimeCSVFileName parameter  
//	}
	
	}

}
