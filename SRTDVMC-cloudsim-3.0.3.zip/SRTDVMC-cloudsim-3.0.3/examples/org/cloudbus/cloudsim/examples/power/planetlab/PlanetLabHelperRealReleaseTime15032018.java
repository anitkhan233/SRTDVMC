package org.cloudbus.cloudsim.examples.power.planetlab;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import readFromCSVFile.RealReleaseTimeFromCSVFile;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelNull;
import org.cloudbus.cloudsim.UtilizationModelPlanetLabInMemory;
import org.cloudbus.cloudsim.examples.power.Constants;

/**
 * A helper class for the running examples for the PlanetLab workload.
 * 
 * If you are using any algorithms, policies or workload included in the power package please cite
 * the following paper:
 * 
 * Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012
 * 
 * @author Anton Beloglazov
 * @since Jan 5, 2012
 */

/*
 * Two Different createCloudletListPlanetLab() exists
 * New createCloudletListPlanetLab() has an additional parameter String inputRealReleaseTimeFileName
 * which is the file name from where real release time would be fetched 
 * for that RealReleaseTimeFromCSVFile() constructor is first called
 * and then getReleaseTimeArray() function is called to get the array of release time
 * which is passed as the the cloudlet length argument of constructor cloudlet()
 * to create a cloudlet with a cloudlet length which is equal to the value 
 * form the input real release time csv file
 */

public class PlanetLabHelperRealReleaseTime15032018 {

	/**
	 * Creates the cloudlet list planet lab.
	 * 
	 * @param brokerId the broker id
	 * @param inputFolderName the input folder name
	 * @return the list
	 * @throws FileNotFoundException the file not found exception
	 */
	public static List<Cloudlet> createCloudletListPlanetLab(int brokerId, String inputFolderName)
			throws FileNotFoundException {
		List<Cloudlet> list = new ArrayList<Cloudlet>();

		long fileSize = 300;
		long outputSize = 300;
		UtilizationModel utilizationModelNull = new UtilizationModelNull();

		File inputFolder = new File(inputFolderName);
		File[] files = inputFolder.listFiles();
		//I have added to create random number to create Cloudlets of different length
		Random rand = new Random();
		int index; //index of Constants.CLOUDLET_LENGTH array--I added
		/*
		//start of I added to retrieve real release time 
		//from readFromCSVFile.realReleaseTimeFromCSVFile.java
		String inputFileName =;
		RealReleaseTimeFromCSVFile realReleaseTimeArray = new RealReleaseTimeFromCSVFile();
		*/
		for (int i = 0; i < files.length; i++) 
		{
			//---start of my added to create random number to create cloudlets of different length
			//rand.nextInt(50) would generate random number in between 0 and 49
			//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
			index = (rand.nextInt((100-1)+1))+1;
			//---end of my added-------------------	
			Cloudlet cloudlet = null;
			try 
			{
				cloudlet = new Cloudlet(
						i,
						Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelPlanetLabInMemory(
								files[i].getAbsolutePath(),
								Constants.SCHEDULING_INTERVAL), utilizationModelNull, utilizationModelNull);
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(i);
			list.add(cloudlet);
		}

		return list;
	}//end of createCloudletListPlanetLab()
	
	/***!!! I Have added additional parameter String inputRealReleaseTimeFileName
	 * to the static function 
	 * createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName)
	 * so that it can be passed as parameter of 
	 * new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName) 
	 * which is called inside of createCloudletListPlanetLab() 
	 *    ********************/
	public static List<Cloudlet> createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName)
			throws FileNotFoundException {
		List<Cloudlet> list = new ArrayList<Cloudlet>();

		long fileSize = 300;
		long outputSize = 300;
		UtilizationModel utilizationModelNull = new UtilizationModelNull();

		File inputFolder = new File(inputFolderName);
		File[] files = inputFolder.listFiles();
		//I have added to create random number to create Cloudlets of different length
		Random rand = new Random();
		int index; //index of Constants.CLOUDLET_LENGTH array--I added
		
		//start of I added to retrieve real release time 
		//from readFromCSVFile.realReleaseTimeFromCSVFile.java
		ArrayList<Double> realReleaseTimeArray = new ArrayList<Double>();
		RealReleaseTimeFromCSVFile realReleaseTimeFromCSVObject = new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName);
		realReleaseTimeArray = realReleaseTimeFromCSVObject.getReleaseTimeArray();
		Iterator<Double> realReleaseTimeArrayIterator = realReleaseTimeArray.iterator();
		
		for (int i = 0; i < files.length; i++) 
		{
			//---start of my added to create random number to create cloudlets of different length
			//rand.nextInt(50) would generate random number in between 0 and 49
			//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
			index = (rand.nextInt((100-1)+1))+1;
			//---end of my added-------------------	
			Cloudlet cloudlet = null;
			try 
			{
				cloudlet = new Cloudlet(
						i,
						//Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						Integer.valueOf(realReleaseTimeArrayIterator.next().toString()),
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelPlanetLabInMemory(
								files[i].getAbsolutePath(),
								Constants.SCHEDULING_INTERVAL), utilizationModelNull, utilizationModelNull);
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(i);
			list.add(cloudlet);
		}

		return list;
	}//end of createCloudletListPlanetLab()
	
}// end of class
