package org.cloudbus.cloudsim.examples.power.planetlab;

public class SRTDVMC_StochasticRealReleaseTime_JAN2014_PlanetLab_3March {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean enableOutput = true;
		boolean outputToFile = false;
		/* Old one
		String inputFolder = NonPowerAware.class.getClassLoader().getResource("workload/planetlab").getPath();
		*/
		//C:\Users\anit\eclipse-workspace\090318 Real Release Time New Servers cloudsim-3.0.3\examples\workload\planetlab//I modified
		//String inputFolder = "C://Users//anit//eclipse-workspace//010418 MRTDVMC Real Release Time New Servers cloudsim-3.0.4//examples//workload//planetlab";
		String inputFolder = SRTDVMC_StochasticRealReleaseTime_JAN2014_PlanetLab_3March.class.getClassLoader().getResource("workload/planetlab").getPath();
		String outputFolder = "output";
		String workload = "20110303"; // PlanetLab workload
		String vmAllocationPolicy = "thr"; // Static Threshold (THR) VM allocation policy
		String vmSelectionPolicy = "mmt"; // Minimum Migration Time (MMT) VM selection policy
		String parameter = "0.8"; // the static utilization threshold
		//I added String realReleaseTimeCSVFileName to get real release time
		//String directoryOfRealReleaseTimeCSVFile = SRTDVMC_StochasticRealReleaseTime_JAN2014_PlanetLab_3March.class.getClassLoader().getResource("workload/datafiles__nectar").getPath();
		
		//datafiles__nectar_processed5/OutliersEliminated
		String directoryOfRealReleaseTimeCSVFile = SRTDVMC_StochasticRealReleaseTime_JAN2014_PlanetLab_3March.class.getClassLoader().getResource("workload/datafiles__nectar").getPath();
	
		String realReleaseTimeCSVFileName = "2014-JAN-LARGE.CSV";
		String realReleaseTimeCSVFilePath = directoryOfRealReleaseTimeCSVFile+"/"+realReleaseTimeCSVFileName;
		//I added on Date 14092018 to create less number of cloudlets and VMs than
				//total number of PlanetLabVMs available in PlanetLab Files
				//So that Release Time based DVMC and Anton can be combined
				double percentageOfCloudletsToBeTakenFromPlanetLabFile = 100.0;
				// percentageOfCloudletsToBeTakenFromPlanetLabFile would be divided by 100
				// and would be used later in PlanetLabRuner ((percentageOfCloudletsToBeTakenFromPlanetLabFile)*(files.length))
				//so that instead of i < files.length
				// i<((percentageOfCloudletsToBeTakenFromPlanetLabFile)*(files.length))
				//would be used as condition in for loop to limit number of created cloudlets 
				//Number of Hosts is adjusted in updated init() of PlanetLabRunner 
				//following ratio between uncompressed # VMs and uncompressed # of Hosts
								
		new PlanetLabRunner(
				enableOutput,
				outputToFile,
				inputFolder,
				outputFolder,
				workload,
				vmAllocationPolicy,
				vmSelectionPolicy,
				parameter,
				realReleaseTimeCSVFilePath, //this file path refers to the real release time file path
				percentageOfCloudletsToBeTakenFromPlanetLabFile); //I added percentageOfCloudletsToBeTakenFromPlanetLabFile parameter  
//	}
	
	}

}
