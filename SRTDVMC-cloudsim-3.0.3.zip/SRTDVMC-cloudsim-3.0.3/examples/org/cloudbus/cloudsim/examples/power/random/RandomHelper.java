/*
 *
 */
package org.cloudbus.cloudsim.examples.power.random;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.PrintInFile;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelNull;
import org.cloudbus.cloudsim.UtilizationModelStochastic;
import org.cloudbus.cloudsim.examples.power.Constants;

import readFromCSVFile.RealReleaseTimeFromCSVFile;

/**
 * The Helper class for the random workload.
 * 
 * If you are using any algorithms, policies or workload included in the power package please cite
 * the following paper:
 * 
 * Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012
 * 
 * @author Anton Beloglazov
 * @since Jan 5, 2012
 */
public class RandomHelper {

	/**
	 * Creates the cloudlet list.
	 * 
	 * @param brokerId the broker id
	 * @param cloudletsNumber the cloudlets number
	 * 
	 * @return the list< cloudlet>
	 */
	public static List<Cloudlet> createCloudletList(int brokerId, int cloudletsNumber) 
	{
		List<Cloudlet> list = new ArrayList<Cloudlet>();

		long fileSize = 300;
		long outputSize = 300;
		long seed = RandomConstants.CLOUDLET_UTILIZATION_SEED;
		UtilizationModel utilizationModelNull = new UtilizationModelNull();
		//I have added to create random number to create Cloudlets of different length
		Random rand = new Random();
		int index; //index of Constants.CLOUDLET_LENGTH array--I added
		
		for (int i = 0; i < cloudletsNumber; i++) 
		{
			//---start of my added to create random number to create cloudlets of different length
			//rand.nextInt(50) would generate random number in between 0 and 49
			//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
			//Constants.maximumIndex maximum how many different cloudlet lengths are there
			//***********************************************************************
	//????????????????????????????????????????????????????????????????????????
			//index = (rand.nextInt((Constants.maximumCloudletListIndex -1)+1))+1;
	//?????????????????????????????????????????????????????????????????????????
			//***********************************************************************
			//String message = null;
			PrintInFile.printInFile(""+i); // i instead of index
			//---end of my added-------------------
			Cloudlet cloudlet = null;
			if (seed == -1) 
			{
				cloudlet = new Cloudlet(
						i,
						//Constants.CLOUDLET_LENGTH[i],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[i % 100]
						
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelStochastic(),
						utilizationModelNull,
						utilizationModelNull);
			} 
			else 
			{
				cloudlet = new Cloudlet(
						i,
						//Constants.CLOUDLET_LENGTH[i],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[i % 100]
	
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelStochastic(seed * i),
						utilizationModelNull,
						utilizationModelNull);
			}
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(i);
			list.add(cloudlet);
		}

		return list;
	}

	
	public static List<Cloudlet> createCloudletList(int brokerId, int cloudletsNumber, String inputRealReleaseTimeFileName) 
	{
		List<Cloudlet> list = new ArrayList<Cloudlet>();

		long fileSize = 300;
		long outputSize = 300;
		long seed = RandomConstants.CLOUDLET_UTILIZATION_SEED;
		UtilizationModel utilizationModelNull = new UtilizationModelNull();
		//I have added to create random number to create Cloudlets of different length
		Random rand = new Random();
		int index; //index of Constants.CLOUDLET_LENGTH array--I added
		
		//start of I added to retrieve real release time 
		//from readFromCSVFile.realReleaseTimeFromCSVFile.java
		ArrayList<Double> realReleaseTimeArray = new ArrayList<Double>();
		RealReleaseTimeFromCSVFile realReleaseTimeFromCSVObject = new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName, cloudletsNumber);
		realReleaseTimeArray = realReleaseTimeFromCSVObject.getReleaseTimeArray();
		Iterator<Double> realReleaseTimeArrayIterator = realReleaseTimeArray.iterator();
		long cloudletLength;
		for (int i = 0; i < cloudletsNumber; i++) 
		{
			//---start of my added to create random number to create cloudlets of different length
			//rand.nextInt(50) would generate random number in between 0 and 49
			//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
			//Constants.maximumIndex maximum how many different cloudlet lengths are there
			//***********************************************************************
	//????????????????????????????????????????????????????????????????????????
			//index = (rand.nextInt((Constants.maximumCloudletListIndex -1)+1))+1;
	//?????????????????????????????????????????????????????????????????????????
			//***********************************************************************
			//String message = null;
			PrintInFile.printInFile(""+i); // i instead of index
			cloudletLength = 60 * ((long) Double.parseDouble(realReleaseTimeArrayIterator.next().toString()));
			
			//---end of my added-------------------
			Cloudlet cloudlet = null;
			if (seed == -1) 
			{
				cloudlet = new Cloudlet(
						i,
						//Constants.CLOUDLET_LENGTH[i],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						//Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[i % 100]
						//I changed the cloudlet length to the following
						//60 * Integer.valueOf(realReleaseTimeArrayIterator.next().toString()),
						cloudletLength,
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelStochastic(),
						utilizationModelNull,
						utilizationModelNull);
			} 
			else 
			{
				cloudlet = new Cloudlet(
						i,
						//Constants.CLOUDLET_LENGTH[i],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[i % 100]
	
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelStochastic(seed * i),
						utilizationModelNull,
						utilizationModelNull);
			}
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(i);
			list.add(cloudlet);
		}

		return list;
	}

	
}
