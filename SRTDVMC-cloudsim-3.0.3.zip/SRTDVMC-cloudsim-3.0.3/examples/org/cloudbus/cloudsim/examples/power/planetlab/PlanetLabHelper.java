package org.cloudbus.cloudsim.examples.power.planetlab;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelNull;
import org.cloudbus.cloudsim.UtilizationModelPlanetLabInMemory;
import org.cloudbus.cloudsim.examples.power.Constants;

import readFromCSVFile.RealReleaseTimeFromCSVFile;

/**
 * A helper class for the running examples for the PlanetLab workload.
 * 
 * If you are using any algorithms, policies or workload included in the power package please cite
 * the following paper:
 * 
 * Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012
 * 
 * @author Anton Beloglazov
 * @since Jan 5, 2012
 */
/*
* Two Different createCloudletListPlanetLab() exists
 * New createCloudletListPlanetLab() has an additional parameter String inputRealReleaseTimeFileName
 * which is the file name from where real release time would be fetched 
 * for that RealReleaseTimeFromCSVFile() constructor is first called
 * and then getReleaseTimeArray() function is called to get the array of release time
 * which is passed as the the cloudlet length argument of constructor cloudlet()
 * to create a cloudlet with a cloudlet length which is equal to the value 
 * form the input real release time csv file
 *  */

public class PlanetLabHelper {

	/**
	 * Creates the cloudlet list planet lab.
	 * 
	 * @param brokerId the broker id
	 * @param inputFolderName the input folder name
	 * @return the list
	 * @throws FileNotFoundException the file not found exception
	 */
	//Start of the old one which do not incorporate the real release time from csv file
	public static List<Cloudlet> createCloudletListPlanetLab(int brokerId, String inputFolderName)
			throws FileNotFoundException {
		List<Cloudlet> list = new ArrayList<Cloudlet>();

		long fileSize = 300;
		long outputSize = 300;
		UtilizationModel utilizationModelNull = new UtilizationModelNull();

		File inputFolder = new File(inputFolderName);
		File[] files = inputFolder.listFiles();
		//I have added to create random number to create Cloudlets of different length
		Random rand = new Random();
		int index; //index of Constants.CLOUDLET_LENGTH array--I added
		
		for (int i = 0; i < files.length; i++) 
		{
			//---start of my added to create random number to create cloudlets of different length
			//rand.nextInt(50) would generate random number in between 0 and 49
			//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
			index = (rand.nextInt((100-1)+1))+1;
			//---end of my added-------------------	
			Cloudlet cloudlet = null;
			try 
			{
				cloudlet = new Cloudlet(
						i,
						Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelPlanetLabInMemory(
								files[i].getAbsolutePath(),
								Constants.SCHEDULING_INTERVAL), utilizationModelNull, utilizationModelNull);
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(i);
			list.add(cloudlet);
		}

		return list;
	}
	//End of the old one which do not incorporate the real release time from csv file
	
	
	//Start of the new one which incorporates real release time from csv file
	/***!!! I Have added additional parameter String inputRealReleaseTimeFileName
	 * to the static function 
	 * createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName)
	 * so that it can be passed as parameter of 
	 * new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName) 
	 * which is called inside of createCloudletListPlanetLab() 
	 *    ********************/
	/*
	public static List<Cloudlet> createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName)
			throws FileNotFoundException {
		List<Cloudlet> list = new ArrayList<Cloudlet>();

		long fileSize = 300;
		long outputSize = 300;
		UtilizationModel utilizationModelNull = new UtilizationModelNull();

		File inputFolder = new File(inputFolderName);
		File[] files = inputFolder.listFiles();
		//I have added to create random number to create Cloudlets of different length
		Random rand = new Random();
		int index; //index of Constants.CLOUDLET_LENGTH array--I added
		
		//start of I added to retrieve real release time 
		//from readFromCSVFile.realReleaseTimeFromCSVFile.java
		ArrayList<Double> realReleaseTimeArray = new ArrayList<Double>();
		RealReleaseTimeFromCSVFile realReleaseTimeFromCSVObject = new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName, files.length);
		realReleaseTimeArray = realReleaseTimeFromCSVObject.getReleaseTimeArray();
		Iterator<Double> realReleaseTimeArrayIterator = realReleaseTimeArray.iterator();
		long cloudletLength;
		for (int i = 0; i < files.length; i++) 
		{
			//---start of my added to create random number to create cloudlets of different length
			//rand.nextInt(50) would generate random number in between 0 and 49
			//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
			index = (rand.nextInt((100-1)+1))+1;
			// I changed cloudletLength on 280518 to make it stochastic realreleasetime
			 
			//earlier one without stochastic
			//cloudletLength = 60 * ((long) Double.parseDouble(realReleaseTimeArrayIterator.next().toString()));
			//Updated 28 may 2018 stochastic cloudletlength
			cloudletLength = (long) (Constants.getStochastic() * 60 * ((long) Double.parseDouble(realReleaseTimeArrayIterator.next().toString())));
			
			//---end of my added-------------------	
			Cloudlet cloudlet = null;
			try 
			{
				cloudlet = new Cloudlet(
						i,
						//Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
						//I changed the cloudlet length to the following
						//60 * Integer.valueOf(realReleaseTimeArrayIterator.next().toString()),
						cloudletLength,
						Constants.CLOUDLET_PES,
						fileSize,
						outputSize,
						new UtilizationModelPlanetLabInMemory(
								files[i].getAbsolutePath(),
								Constants.SCHEDULING_INTERVAL), utilizationModelNull, utilizationModelNull);
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(i);
			list.add(cloudlet);
		}

		return list;
	}//end of createCloudletListPlanetLab()
	//End of the new one which incorporates real release time from csv file
	*/
	
	//**Updated 29May2018 to create cloudlets for all VMs in one month's VMRT CSV file
	//Start of the new one which incorporates real release time from csv file
		/***!!! I Have added additional parameter String inputRealReleaseTimeFileName
		 * to the static function 
		 * createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName)
		 * so that it can be passed as parameter of 
		 * new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName) 
		 * which is called inside of createCloudletListPlanetLab() 
		 *    ********************/
		public static List<Cloudlet> createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName)
				throws FileNotFoundException {
			List<Cloudlet> list = new ArrayList<Cloudlet>();

			long fileSize = 300;
			long outputSize = 300;
			UtilizationModel utilizationModelNull = new UtilizationModelNull();

			File inputFolder = new File(inputFolderName);
			File[] files = inputFolder.listFiles();
			//I have added to create random number to create Cloudlets of different length
			//Random rand = new Random();
			//int index; //index of Constants.CLOUDLET_LENGTH array--I added	
			//start of I added to retrieve real release time 
			//from readFromCSVFile.realReleaseTimeFromCSVFile.java
			ArrayList<Double> realReleaseTimeArray = new ArrayList<Double>();
			RealReleaseTimeFromCSVFile realReleaseTimeFromCSVObject = new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName);
			int totalNumberOfVms = realReleaseTimeFromCSVObject.getTotalNumberOfVMs();
			realReleaseTimeArray = realReleaseTimeFromCSVObject.getReleaseTimeArray();
			Iterator<Double> realReleaseTimeArrayIterator = realReleaseTimeArray.iterator();
			long cloudletLength;
			for (int i = 0; i < totalNumberOfVms; i++) 
			{
				//---start of my added to create random number to create cloudlets of different length
				//rand.nextInt(50) would generate random number in between 0 and 49
				//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
				//index = (rand.nextInt((100-1)+1))+1;
				/*
				 * I changed cloudletLength on 280518 to make it stochastic realreleasetime
				 */
				//earlier one without stochastic
				//cloudletLength = 60 * ((long) Double.parseDouble(realReleaseTimeArrayIterator.next().toString()));
				//Updated 28 may 2018 stochastic cloudletlength
				cloudletLength = (long) (Constants.getStochastic() * 60 * ((long) Double.parseDouble(realReleaseTimeArrayIterator.next().toString())));
				
				//---end of my added-------------------	
				Cloudlet cloudlet = null;
				try 
				{
					cloudlet = new Cloudlet(
							i,
							//Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
							//I changed the cloudlet length to the following
							//60 * Integer.valueOf(realReleaseTimeArrayIterator.next().toString()),
							cloudletLength,
							Constants.CLOUDLET_PES,
							fileSize,
							outputSize,
							new UtilizationModelPlanetLabInMemory(
									files[i % files.length].getAbsolutePath(),
									Constants.SCHEDULING_INTERVAL), utilizationModelNull, utilizationModelNull);
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(0);
				}
				cloudlet.setUserId(brokerId);
				cloudlet.setVmId(i);
				list.add(cloudlet);
			}

			return list;
		}//end of createCloudletListPlanetLab()
		//End of the new one which incorporates real release time from csv file
		
		/*
		 * Date: 14092018 
		 * Start of new PlanetLabHelper to create less number of Cloudlets
		 * than the available number of real PlanetLab files or real PlanetLab VMs
		 * For example, if there is data or files of 1200 PlanetLab VMs usage
		 * only some of those 1200 PlanetLab VMs would be picked randomly
		 * Reason is to combine both SRTDVMC for 80% VMs,PMs and Anton 20% VMs,PMs
		 */
		//**Updated 29May2018 to create cloudlets for all VMs in one month's VMRT CSV file
		//Start of the new one which incorporates real release time from csv file
			/***!!! I Have added additional parameter String inputRealReleaseTimeFileName
			 * to the static function 
			 * createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName)
			 * so that it can be passed as parameter of 
			 * new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName) 
			 * which is called inside of createCloudletListPlanetLab() 
			 *    ********************/
		
		public static List<Cloudlet> createCloudletListPlanetLab(int brokerId, String inputFolderName, String inputRealReleaseTimeFileName, double percentageOfCloudletsToBeTakenFromPlanetLabFile)
				throws FileNotFoundException {
			List<Cloudlet> list = new ArrayList<Cloudlet>();

			/*
			 * on 10 October 2018 High scaled cloudletLength with min = 24*60*60 and max = 365 * min
			 */
			/*
			 * 
			 * On 17/10/2018 commented it out to change it back to real original VMRT
			double min = 24*60*60;
			double max = 365 * min;
			double differenceOfMaxAndMin = max-min;
			*/			
			
			long fileSize = 300;
			long outputSize = 300;
			UtilizationModel utilizationModelNull = new UtilizationModelNull();

			File inputFolder = new File(inputFolderName);
			File[] files = inputFolder.listFiles();
			//I have added to create random number to create Cloudlets of different length
			//Random rand = new Random();
			//int index; //index of Constants.CLOUDLET_LENGTH array--I added	
			//start of I added to retrieve real release time 
			//from readFromCSVFile.realReleaseTimeFromCSVFile.java
			ArrayList<Double> realReleaseTimeArray = new ArrayList<Double>();
			RealReleaseTimeFromCSVFile realReleaseTimeFromCSVObject = new RealReleaseTimeFromCSVFile(inputRealReleaseTimeFileName);
			int totalNumberOfVms = realReleaseTimeFromCSVObject.getTotalNumberOfVMs();
			realReleaseTimeArray = realReleaseTimeFromCSVObject.getReleaseTimeArray();
			Iterator<Double> realReleaseTimeArrayIterator = realReleaseTimeArray.iterator();
			long cloudletLength;
			
			int reducedNumberOfCloudlets = (int) Math.floor(((percentageOfCloudletsToBeTakenFromPlanetLabFile / 100)*(totalNumberOfVms)));
			
			
			for (int i = 0; i < reducedNumberOfCloudlets; i++) 
			{
				//---start of my added to create random number to create cloudlets of different length
				//rand.nextInt(50) would generate random number in between 0 and 49
				//rand.nextInt((max-min)+1)+min; // to generate in between 1 and 50
				//index = (rand.nextInt((100-1)+1))+1;
				/*
				 * I changed cloudletLength on 280518 to make it stochastic realreleasetime
				 */
				//earlier one without stochastic
				//cloudletLength = 60 * ((long) Double.parseDouble(realReleaseTimeArrayIterator.next().toString()));
				//Updated 28 may 2018 stochastic cloudletlength
				cloudletLength = (long) (Constants.getStochastic() * 60 * ((long) Double.parseDouble(realReleaseTimeArrayIterator.next().toString())));
				
				/*
				 * on 10 October 2018 High scaled cloudletLength with min = 24*60*60 and max = 365 * min
				 * * On 17/10/2018 commented it out to change it back to real original VMRT
				 */
				//double min = 24*60*60;
				//double max = 365 * min;
				//double differenceOfMaxAndMin = max-min;
				//cloudletLength = (long) (Constants.getStochastic() * (min + ((Double.parseDouble(realReleaseTimeArrayIterator.next().toString()))/(differenceOfMaxAndMin))));
				
				//---end of my added-------------------	
				Cloudlet cloudlet = null;
				try 
				{
					cloudlet = new Cloudlet(
							i,
							//Constants.CLOUDLET_LENGTH[i % 100],//changed CLOUDLET_LENGTH by CLOUDLET_LENGTH[index]
							//I changed the cloudlet length to the following
							//60 * Integer.valueOf(realReleaseTimeArrayIterator.next().toString()),
							cloudletLength,
							Constants.CLOUDLET_PES,
							fileSize,
							outputSize,
							new UtilizationModelPlanetLabInMemory(
									files[i % files.length].getAbsolutePath(),
									Constants.SCHEDULING_INTERVAL), utilizationModelNull, utilizationModelNull);
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(0);
				}
				cloudlet.setUserId(brokerId);
				cloudlet.setVmId(i);
				list.add(cloudlet);
			}

			return list;
		}//end of createCloudletListPlanetLab()
		//End of the new one which incorporates real release time from csv file
				
		
}
