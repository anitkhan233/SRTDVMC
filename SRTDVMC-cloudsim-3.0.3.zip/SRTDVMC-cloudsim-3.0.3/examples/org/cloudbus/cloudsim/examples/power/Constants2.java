package org.cloudbus.cloudsim.examples.power;

import org.cloudbus.cloudsim.power.models.PowerModel;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G4Xeon3040;
import org.cloudbus.cloudsim.power.models.PowerModelSpecPowerHpProLiantMl110G5Xeon3075;

/**
 * If you are using any algorithms, policies or workload included in the power package, please cite
 * the following paper:
 *
 * Anton Beloglazov, and Rajkumar Buyya, "Optimal Online Deterministic Algorithms and Adaptive
 * Heuristics for Energy and Performance Efficient Dynamic Consolidation of Virtual Machines in
 * Cloud Data Centers", Concurrency and Computation: Practice and Experience (CCPE), Volume 24,
 * Issue 13, Pages: 1397-1420, John Wiley & Sons, Ltd, New York, USA, 2012
 *
 * @author Anton Beloglazov
 * @since Jan 6, 2012
 */
public class Constants2 {

	public final static boolean ENABLE_OUTPUT = true;
	public final static boolean OUTPUT_CSV    = false;

	public final static double SCHEDULING_INTERVAL = 300;
	public final static double SIMULATION_LIMIT = 24 * 60 * 60;

	/*
//----------start of Anton's Cloudlet Length---------------------------------------
	public final static int CLOUDLET_LENGTH	= 2500 * (int) SIMULATION_LIMIT;
//-------------end of anton's cloudlet Length-------------------------------------------	
 * 
 */
	//-----start of my added------------------------------------------------
	//Constants.maximumIndex maximum how many different cloudlet lengths are there
	//Constants.maximumIndex is used in RandomHelper to generate random in maximum range of Constants.maximumIndex
	public static int maximumCloudletListIndex = 99; //update it with the total number of different cloudlet lengths
	//Just update Constants.maximumIndex with the change in total number of different cloudlets
	//if we change Constants.maximumInde, then in RandomHelper we wouldn't need to change
	
	static int length1 = (1 * (int) SIMULATION_LIMIT);
	static int length2 = (2 * (int) SIMULATION_LIMIT);
	static int length3 = (3 * (int) SIMULATION_LIMIT);
	static int length4 = (4 * (int) SIMULATION_LIMIT);
	static int length5 = (5 * (int) SIMULATION_LIMIT);
	static int length6 = (6 * (int) SIMULATION_LIMIT);
	static int length7 = (7 * (int) SIMULATION_LIMIT);
	static int length8 = (8 * (int) SIMULATION_LIMIT);
	static int length9 = (9 * (int) SIMULATION_LIMIT);
	static int length10 = (10 * (int) SIMULATION_LIMIT);
	static int length11 = (15 * (int) SIMULATION_LIMIT);
	static int length12 = (20 * (int) SIMULATION_LIMIT);
	static int length13 = (30 * (int) SIMULATION_LIMIT);
	static int length14 = (40 * (int) SIMULATION_LIMIT);
	static int length15 = (50 * (int) SIMULATION_LIMIT);
	static int length16 = (60 * (int) SIMULATION_LIMIT);
	static int length17 = (70 * (int) SIMULATION_LIMIT);
	static int length18 = (80 * (int) SIMULATION_LIMIT);
	static int length19 = (90 * (int) SIMULATION_LIMIT);
	static int length20 = (100 * (int) SIMULATION_LIMIT);
	static int length21 = (250 * (int) SIMULATION_LIMIT);
	static int length22 = (200 * (int) SIMULATION_LIMIT);
	static int length23 = (300 * (int) SIMULATION_LIMIT);
	static int length24 = (400 * (int) SIMULATION_LIMIT);
	static int length25 = (500 * (int) SIMULATION_LIMIT);
	static int length26 = (600 * (int) SIMULATION_LIMIT);
	static int length27 = (700 * (int) SIMULATION_LIMIT);
	static int length28 = (800 * (int) SIMULATION_LIMIT);
	static int length29 = (900 * (int) SIMULATION_LIMIT);
	static int length30 = (1000 * (int) SIMULATION_LIMIT);
	static int length31 = (1100 * (int) SIMULATION_LIMIT);
	static int length32 = (1200 * (int) SIMULATION_LIMIT);
	static int length33 = (1300 * (int) SIMULATION_LIMIT);
	static int length34 = (1400 * (int) SIMULATION_LIMIT);
	static int length35 = (1500 * (int) SIMULATION_LIMIT);
	static int length36 = (1600 * (int) SIMULATION_LIMIT);
	static int length37 = (1700 * (int) SIMULATION_LIMIT);
	static int length38 = (1800 * (int) SIMULATION_LIMIT);
	static int length39 = (1900 * (int) SIMULATION_LIMIT);
	static int length40 = (2000 * (int) SIMULATION_LIMIT);
	static int length41 = (2050 * (int) SIMULATION_LIMIT);
	static int length42 = (2100 * (int) SIMULATION_LIMIT);
	static int length43 = (2150 * (int) SIMULATION_LIMIT);
	static int length44 = (2200 * (int) SIMULATION_LIMIT);
	static int length45 = (2250 * (int) SIMULATION_LIMIT);
	static int length46 = (2300 * (int) SIMULATION_LIMIT);
	static int length47 = (2350 * (int) SIMULATION_LIMIT);
	static int length48 = (2400 * (int) SIMULATION_LIMIT);
	static int length49 = (2450 * (int) SIMULATION_LIMIT);
	static int length50 = (2500 * (int) SIMULATION_LIMIT);
	static int length51 = (2550 * (int) SIMULATION_LIMIT);
	static int length52 = (2600 * (int) SIMULATION_LIMIT);
	static int length53 = (2650 * (int) SIMULATION_LIMIT);
	static int length54 = (2700 * (int) SIMULATION_LIMIT);
	static int length55 = (2750 * (int) SIMULATION_LIMIT);
	static int length56 = (2800 * (int) SIMULATION_LIMIT);
	static int length57 = (2850 * (int) SIMULATION_LIMIT);
	static int length58 = (2900 * (int) SIMULATION_LIMIT);
	static int length59 = (2950 * (int) SIMULATION_LIMIT);
	static int length60 = (3000 * (int) SIMULATION_LIMIT);
	static int length61 = (3050 * (int) SIMULATION_LIMIT);
	static int length62 = (3100 * (int) SIMULATION_LIMIT);
	static int length63 = (3250 * (int) SIMULATION_LIMIT);
	static int length64 = (3300 * (int) SIMULATION_LIMIT);
	static int length65 = (3350 * (int) SIMULATION_LIMIT);
	static int length66 = (3400 * (int) SIMULATION_LIMIT);
	static int length67 = (3450 * (int) SIMULATION_LIMIT);
	static int length68 = (3500 * (int) SIMULATION_LIMIT);
	static int length69 = (3550 * (int) SIMULATION_LIMIT);
	static int length70 = (3600 * (int) SIMULATION_LIMIT);
	static int length71 = (3650 * (int) SIMULATION_LIMIT);
	static int length72 = (3700 * (int) SIMULATION_LIMIT);
	static int length73 = (3750 * (int) SIMULATION_LIMIT);
	static int length74 = (3800 * (int) SIMULATION_LIMIT);
	static int length75 = (3850 * (int) SIMULATION_LIMIT);
	static int length76 = (3900 * (int) SIMULATION_LIMIT);
	static int length77 = (3950 * (int) SIMULATION_LIMIT);
	static int length78 = (4000 * (int) SIMULATION_LIMIT);
	static int length79 = (4250 * (int) SIMULATION_LIMIT);
	static int length80 = (4300 * (int) SIMULATION_LIMIT);
	static int length81 = (4350 * (int) SIMULATION_LIMIT);
	static int length82 = (4400 * (int) SIMULATION_LIMIT);
	static int length83 = (4450 * (int) SIMULATION_LIMIT);
	static int length84 = (4500 * (int) SIMULATION_LIMIT);
	static int length85 = (4550 * (int) SIMULATION_LIMIT);
	static int length86 = (4600 * (int) SIMULATION_LIMIT);
	static int length87 = (4650 * (int) SIMULATION_LIMIT);
	static int length88 = (4700 * (int) SIMULATION_LIMIT);
	static int length89 = (4750 * (int) SIMULATION_LIMIT);
	static int length90 = (4800 * (int) SIMULATION_LIMIT);
	static int length91 = (4850 * (int) SIMULATION_LIMIT);
	static int length92 = (4900 * (int) SIMULATION_LIMIT);
	static int length93 = (4950 * (int) SIMULATION_LIMIT);
	static int length94 = (5000 * (int) SIMULATION_LIMIT);
	static int length95 = (5050 * (int) SIMULATION_LIMIT);
	static int length96 = (5100 * (int) SIMULATION_LIMIT);
	static int length97 = (5150 * (int) SIMULATION_LIMIT);
	static int length98 = (5200 * (int) SIMULATION_LIMIT);
	static int length99 = (5250 * (int) SIMULATION_LIMIT);
	static int length100 = (5300 * (int) SIMULATION_LIMIT);
	
	
	public final static int[] CLOUDLET_LENGTH	= { 
			length1, length2, length3, length4, length5, 
			length6, length7, length8, length9, length10,
			length11, length12, length13, length14, length15, 
			length16, length17, length18, length19, length20, 
			length21, length22, length23, length24, length25, 
			length26, length27, length28, length29, length30,
			length31, length32, length33, length34, length35, 
			length36, length37, length38, length39, length40, 
			length41, length42, length43, length44, length45, 
			length46, length47, length48, length49, length50, 
			length51, length52, length53, length54, length55, 
			length56, length57, length58, length59, length60,
			length61, length62, length63, length64, length65, 
			length66, length67, length68, length69, length70, 
			length71, length72, length73, length74, length75, 
			length76, length77, length78, length79, length80,
			length81, length82, length83, length84, length85, 
			length86, length87, length88, length89, length90, 
			length91, length92, length93, length94, length95, 
			length96, length97, length98, length99, length100};
	
	//-----end of my added----------------------------------------------
	
	public final static int CLOUDLET_PES	= 1;

	/*
	 * VM instance types:
	 *   High-Memory Extra Large Instance: 3.25 EC2 Compute Units, 8.55 GB // too much MIPS
	 *   High-CPU Medium Instance: 2.5 EC2 Compute Units, 0.85 GB
	 *   Extra Large Instance: 2 EC2 Compute Units, 3.75 GB
	 *   Small Instance: 1 EC2 Compute Unit, 1.7 GB
	 *   Micro Instance: 0.5 EC2 Compute Unit, 0.633 GB
	 *   We decrease the memory size two times to enable oversubscription
	 *
	 */
	public final static int VM_TYPES	= 4;
	public final static int[] VM_MIPS	= { 2500, 2000, 1000, 500 };
	public final static int[] VM_PES	= { 1, 1, 1, 1 };
	public final static int[] VM_RAM	= { 870,  1740, 1740, 613 };
	public final static int VM_BW		= 100000; // 100 Mbit/s
	public final static int VM_SIZE		= 2500; // 2.5 GB

	/*
	 * Host types:
	 *   HP ProLiant ML110 G4 (1 x [Xeon 3040 1860 MHz, 2 cores], 4GB)
	 *   HP ProLiant ML110 G5 (1 x [Xeon 3075 2660 MHz, 2 cores], 4GB)
	 *   We increase the memory size to enable over-subscription (x4)
	 */
	public final static int HOST_TYPES	 = 2;
	public final static int[] HOST_MIPS	 = { 1860, 2660 };
	public final static int[] HOST_PES	 = { 2, 2 };
	public final static int[] HOST_RAM	 = { 4096, 4096 };
	public final static int HOST_BW		 = 1000000; // 1 Gbit/s
	public final static int HOST_STORAGE = 1000000; // 1 GB

	public final static PowerModel[] HOST_POWER = {
		new PowerModelSpecPowerHpProLiantMl110G4Xeon3040(),
		new PowerModelSpecPowerHpProLiantMl110G5Xeon3075()
	};

}
